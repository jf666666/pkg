---
name: "❓ Ask question"
about: Ask a question about carbon
labels: Question
---

<!--

Before asking a question, make sure you have:

- Searched existing Stack Overflow questions.
- Googled your question.
- Searched open and closed [GitHub issues](https://github.com/golang-module/carbon/issues?utf8=%E2%9C%93&q=is%3Aissue)
- Read the documentation:
  - [Carbon Readme](https://github.com/golang-module/carbon)
-->
